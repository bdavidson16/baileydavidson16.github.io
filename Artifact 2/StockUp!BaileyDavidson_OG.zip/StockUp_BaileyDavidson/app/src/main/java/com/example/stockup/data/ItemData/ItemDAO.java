package com.example.stockup.data.ItemData;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

// source: https://developer.android.com/training/data-storage/room
@Dao
public interface ItemDAO {
    @Query("SELECT * FROM item")
    LiveData<List<Item>> getAllItems();

    @Query("SELECT * FROM item WHERE itemName = :name LIMIT 1")
    Item getItemByName(String name);

    @Update
    void update(Item item);

    @Insert
    void insert(Item... items);

    @Delete
    void delete(Item item);

    @Query("SELECT * FROM item WHERE itemName = :item")
    Item getName(String item);
}
