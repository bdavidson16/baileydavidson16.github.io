package com.example.stockup.ui.login;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.room.Room;

import com.example.stockup.R;
import com.example.stockup.data.LoginData.Login;
import com.example.stockup.data.LoginData.LoginDAO;
import com.example.stockup.data.LoginData.LoginDatabase;
import com.example.stockup.ui.Items.ItemActivity;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

// this class adds functionality to the login screen, which the app opens up to
// it takes user input for username and password and either logs to user in or
// registers them as a new user, to then open up the inventory list
// sources: https://developer.android.com/reference/androidx/appcompat/app/AppCompatActivity
// https://developer.android.com/guide/components/intents-filters
public class LoginActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private Button registerButton;

    private LoginDAO loginDAO;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login); // connection to login screen

        // bind views on login screen
        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        loginButton = findViewById(R.id.buttonLogin);
        registerButton = findViewById(R.id.buttonRegister);

        // set up Room and DAO
        LoginDatabase db = Room.databaseBuilder(getApplicationContext(),
                        LoginDatabase.class, "login_database")
                .allowMainThreadQueries()
                .build();
        loginDAO = db.loginDao();

        // set up listeners for buttons
        loginButton.setOnClickListener(view -> attemptLogin());
        registerButton.setOnClickListener(view -> registerUser());

        // hide systems bar to make app fully immersive
        // source: https://developer.android.com/develop/ui/views/layout/immersive
        WindowInsetsControllerCompat windowInsetsController =
                WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());

        // Automatically hide system bars (status + nav), and let users swipe to reveal them temporarily
        windowInsetsController.setSystemBarsBehavior(
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        );

        // Hide system bars immediately
        windowInsetsController.hide(WindowInsetsCompat.Type.systemBars());
    }

    // checks if login info is there and correct for an existing user
    private void attemptLogin() {
        String username = usernameEditText.getText().toString().trim().toLowerCase();
        String password = passwordEditText.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // executes database query on background thread
        Executor executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            Login user = loginDAO.getLoginName(username);
            runOnUiThread(() -> {
                if (user != null && user.getPassWord().equals(password)) {
                    Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();

                    // Start ItemActivity
                    Intent intent = new Intent(LoginActivity.this, ItemActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            });
        });
    }

    // when user click register, systems checks if fields are filled in and if user exists, if not
    // new user is register, if user exists user is notified.
    private void registerUser() {
        String username = usernameEditText.getText().toString().trim().toLowerCase();
        String password = passwordEditText.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if user already exists
        if (loginDAO.getLoginName(username) != null) {
            Toast.makeText(this, "User already exists", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create new user
        Login newUser = new Login();
        newUser.setUserName(username);
        newUser.setPassWord(password);
        loginDAO.insert(newUser);

        Toast.makeText(this, "User registered successfully", Toast.LENGTH_SHORT).show();

        // once registered, user is asked to login again
        attemptLogin();
    }
}
