package com.example.stockup.data.ItemData;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

// model class - transfers from one layer to another
// name of the class "Item" defines the table name, its fields' names define column names,
// and each object of it is a row in the database
@Entity(tableName = "item")
public class Item {
    @NonNull
    @PrimaryKey
    private String itemName;
    private int quantity;

    public Item() {
        itemName = "";
    }

    public Item(@NonNull String name, int quantity) {
        this.itemName = name;
        this.quantity = quantity;
    }

    @NonNull
    public String getItemName() {
        return itemName;
    }

    public void setItemName(@NonNull String itemName) {
        this.itemName = itemName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
