package com.example.stockup.data.LoginData;

// to interact with SQLite dbs
import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

// @Database is an observable data holder class - used to prevent memory leaks in this application
// basically extends database for data protection
// sources: https://developer.android.com/training/data-storage/room/sqlite-room-migration#java
// https://developer.android.com/training/data-storage/room
@Database(entities = {Login.class}, version = 1, exportSchema = false)
public abstract class LoginDatabase extends RoomDatabase {

    private static volatile LoginDatabase INSTANCE;

    // builds database off of single instance to potential conflicts if there
    // were multiple instances, this helps keep consistency app-wide
    public static LoginDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (LoginDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    LoginDatabase.class, "MY_ROOM_DATABASE")
                            .build();
                }
            }
        }
        return INSTANCE;
    }

    // Make sure this DAO refers to the correct DAO interface
    public abstract LoginDAO loginDao();
}
