package com.example.stockup.ui.Items;

//page features
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.annotation.OptIn;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.media3.common.util.Log;
import androidx.media3.common.util.UnstableApi;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;

// calls data files for Item info
import com.example.stockup.R;
import com.example.stockup.data.ItemData.Item;
import com.example.stockup.data.ItemData.ItemDAO;
import com.example.stockup.data.ItemData.ItemDatabase; //tap into db
import com.example.stockup.ui.SMS.SMS;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

// this class manages the list view of items in inventory,
// and allows the user to select the floating plus button
// or arrow to add or edit/delete items, respectively.
// Doing so by using Item, ItemDAO, and ItemDatabase and applying them
// to the UI item page
// sources: https://www.geeksforgeeks.org/android-recyclerview/
// https://developer.android.com/reference/androidx/appcompat/app/AppCompatActivity
// https://developer.android.com/guide/components/intents-filters
public class ItemActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ItemDAO itemDao;
    private static final int ADD_ITEM_REQUEST_CODE = 1;
    private ActivityResultLauncher<Intent> addItemLauncher; //used to switch screens

    @OptIn(markerClass = UnstableApi.class)
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_list); //connects to item_list.xml

        recyclerView = findViewById(R.id.list);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // int. database and itemDAO, builds off instance
        ItemDatabase db = Room.databaseBuilder(getApplicationContext(),
                        ItemDatabase.class, "items-db")
                .allowMainThreadQueries()
                .build();

        itemDao = db.itemDAO(); // created to manage item list using CRUD ops

        Log.d("ItemActivity", "itemDao is " + (itemDao == null ? "null" : "not null"));

        // lets user edit/delete item by selecting item name or quantity
        // screen opens EditItemActivity
        ItemAdapter adapter = new ItemAdapter(new ArrayList<>());
        adapter.setOnItemClickListener(item -> {
            Intent intent = new Intent(ItemActivity.this, EditItemActivity.class);
            intent.putExtra("item_name", item.getItemName());
            intent.putExtra("item_quantity", item.getQuantity());
            addItemLauncher.launch(intent);
        });
        recyclerView.setAdapter(adapter);

        addItemLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        loadItems(); // refresh list after adding/editing
                    }
                });

        // floating activity buton to open EditItemActivity
        FloatingActionButton fab = findViewById(R.id.idFABAdd);
        fab.setOnClickListener(view -> {
            Intent intent = new Intent(ItemActivity.this, EditItemActivity.class);
            addItemLauncher.launch(intent);
        });

        // floating activity button to open SMS
        FloatingActionButton fabSMS = findViewById(R.id.idFABSMS);
        fabSMS.setOnClickListener(view -> {
            Intent intent = new Intent(ItemActivity.this, SMS.class);
            addItemLauncher.launch(intent);
        });

        // load and set items
        loadItems();

        // hide systems bar to make app fully immersive
        // source: https://developer.android.com/develop/ui/views/layout/immersive
        WindowInsetsControllerCompat windowInsetsController =
                WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());

        // Automatically hide system bars (status + nav), and let users swipe to reveal them temporarily
        windowInsetsController.setSystemBarsBehavior(
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        );

        // Hide system bars immediately
        windowInsetsController.hide(WindowInsetsCompat.Type.systemBars());
    }
    // retrieves all items (synchronously)
    private void loadItems() {
        itemDao.getAllItems().observe(this, itemList -> {
            ItemAdapter adapter = new ItemAdapter(itemList, item -> {
                Intent intent = new Intent(ItemActivity.this, EditItemActivity.class);
                intent.putExtra("item_name", item.getItemName());
                intent.putExtra("item_quantity", item.getQuantity());
                addItemLauncher.launch(intent);
            });
            recyclerView.setAdapter(adapter);
        });
    }

    // refreshes list after EditItemActivity
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ADD_ITEM_REQUEST_CODE && resultCode == RESULT_OK) {
            loadItems();
        }
    }
}