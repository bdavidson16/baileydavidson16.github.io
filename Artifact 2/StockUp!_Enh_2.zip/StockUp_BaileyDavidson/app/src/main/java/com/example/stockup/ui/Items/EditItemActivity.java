package com.example.stockup.ui.Items;

// page features
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

// Room used for data storage and manipulation
import androidx.appcompat.app.AppCompatActivity;

// calls data files for Item info
import com.example.stockup.R;
import com.example.stockup.data.ItemData.Item;
import com.example.stockup.data.ItemData.ItemRF;

// this class manages the page to edit/delete items
// by using Item and ItemRF and applying them
// to the UI item list page
// sources:   https://www.geeksforgeeks.org/toasts-android-studio/
// https://developer.android.com/reference/android/os/Bundle
// https://developer.android.com/guide/components/intents-filters
// https://www.geeksforgeeks.org/what-is-toast-and-how-to-use-it-in-android-with-examples/

public class EditItemActivity extends AppCompatActivity {
    private EditText editTextName, editTextQuantity;
    private ItemRF itemRF;
    private Item existingItem = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item); // connection to item edit page

        // fields and buttons on page
        editTextName = findViewById(R.id.idEdtItemName);
        editTextQuantity = findViewById(R.id.idEditItemQuantity);
        Button buttonSave = findViewById(R.id.idBtnSave);
        Button buttonDelete = findViewById(R.id.idBtnDelete);

        ImmersiveModeHelper.enableImmersiveMode(this);

        // NEED TO UPDATE for Retrofit
        // builds on db instance, creates itemDAO for CRUD functionality on thread
        ItemDatabase db = Room.databaseBuilder(getApplicationContext(),
                        ItemDatabase.class, "items-db")
                .allowMainThreadQueries()
                .build();
        itemRF = db.ItemRF();

        // Check for passed item name to edit
        String itemName = getIntent().getStringExtra("item_name");
        if (itemName != null) {
            existingItem = itemRF.getItemByName(itemName);
            if (existingItem != null) {
                editTextName.setText(existingItem.getItemName());
                editTextName.setEnabled(false); // don't allow name changes
                editTextQuantity.setText(String.valueOf(existingItem.getQuantity()));
            }
        } else {
            buttonDelete.setEnabled(false); // disable delete for new item
        }

        // NEED TO UPDATE, edit update, insert, and delete
        // when user clicks Save button, checks fields, adds item, and notifies user
        buttonSave.setOnClickListener(v -> {
            String name = editTextName.getText().toString().trim();
            String quantityStr = editTextQuantity.getText().toString().trim();

            // notification if field(s) are empty
            if (TextUtils.isEmpty(name) || TextUtils.isEmpty(quantityStr)) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            int quantity = Integer.parseInt(quantityStr); // change to smaller value/mem. allocation

            // update item if exists - should this be user option? admin access?
            if (existingItem != null) {
                existingItem.setQuantity(quantity);
                itemRF.update(existingItem); // NEED TO EDIT
                // notification of updated item
                Toast.makeText(this, "Item updated", Toast.LENGTH_SHORT).show();
            } else { // else create new item
                Item newItem = new Item(name, quantity); // NEED TO EDIT
                itemRF.insert(newItem); // NEED TO EDIT
                // notification of item added
                Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
            }
            setResult(RESULT_OK);
            finish();
        });

        // deletes items and notifies user when they select delete button
        buttonDelete.setOnClickListener(v -> {
            if (existingItem != null) {
                itemRF.delete(existingItem); // NEED TO EDIT
                // delete notification for user only if item exists and deletes
                Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
                setResult(RESULT_OK);
                finish();
            }
        });
    }
}
