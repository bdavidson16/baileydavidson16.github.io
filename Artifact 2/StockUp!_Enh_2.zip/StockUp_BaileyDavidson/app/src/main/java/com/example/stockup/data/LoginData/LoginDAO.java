package com.example.stockup.data.LoginData;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

// source: https://developer.android.com/training/data-storage/room
@Dao
public interface LoginDAO {

    @Query("SELECT * FROM login")
    LiveData<List<Login>> getAllLogins();

    @Query("SELECT * FROM login WHERE username = :userName LIMIT 1")
    Login getLoginName(String userName);

    @Update
    void update(Login login); // updated names to be clearer

    @Insert
    void insert(Login... logins); // updated names to be clearer

    @Delete
    void delete(Login login); // updated names to be clearer
}
