package com.example.stockup.data.ItemData;

// to interact with SQLite dbs
import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

// @Database is an observable data holder class - used to prevent memory leaks in this application
// basically extends database for data protection
// sources: https://developer.android.com/training/data-storage/room/sqlite-room-migration#java
// https://developer.android.com/training/data-storage/room
@Database(entities = {Item.class}, version = 1, exportSchema = false)
public abstract class ItemDatabase extends RoomDatabase {

    private static volatile ItemDatabase INSTANCE;

    // builds database off of single instance to potential conflicts if there
    // were multiple instances, this helps keep consistency app-wide
    public static ItemDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (ItemDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    ItemDatabase.class, "MY_ROOM_DATABASE")
                            .build();
                }  // else??
            }
        } // else??
        return INSTANCE;
    }
// Source: https://square.github.io/retrofit/configuration/

//    Updated Retrofit Instance
//    Retrofit retrofit = new Retrofit.Builder()
//            .baseUrl("http://your-api-url.com/")  // Include trailing slash
//            .addConverterFactory(GsonConverterFactory.create())
//            .build();
//
//    ItemDatabase itemDatabase = retrofit.create(ItemDatabase.class);

    // Make sure this DAO refers to the correct DAO interface
    public abstract ItemDAO itemDAO();
}





