package com.example.stockup.data.ItemData;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Query; // or @Path, @Body, etc.

import retrofit2.Callback;
import retrofit2.Response;

import java.util.List;

// sources: https://square.github.io/retrofit/declarations/
// https://github.com/square/retrofit
public interface ItemRF {
    @GET("/items")
    Call<List<Item>> getAllItems();

    @GET("/search")
    Call<Item> searchItem(@Query("barcode") String barcode);

    @POST("/insert")
    Call<Void> insertItem(@Body Item item);

    @PUT("/update")
    Call<Void> updateItem(@Body Item item);

    @DELETE("/delete")
    Call<Void> deleteItem(@Query("barcode") String barcode);
}
