package com.example.stockup.ui.Items;

//page features
import android.annotation.SuppressLint;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

//calls item data
import com.example.stockup.R;
import com.example.stockup.data.ItemData.Item;

// used to show item data in list
import java.util.ArrayList;
import java.util.List;

// this class is used to create and manipulate a list of items from the database to
// eventually show on the UI list_items.xml
// sources: https://developer.android.com/develop/ui/views/layout/recyclerview
// https://github.com/android/views-widgets-samples/blob/main/RecyclerView/Application/src/main/java/com/example/android/recyclerview/CustomAdapter.java
public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder> {
    private List<Item> itemList = new ArrayList<>(); //creates list of items
    private OnItemClickListener onItemClickListener;

    public ItemAdapter(List<Item> itemList) {
        this.itemList = itemList;
    }

    // Define the OnItemClickListener interface
    public interface OnItemClickListener {
        void onEditClick(Item item);
    }

    public ItemAdapter(List<Item> itemList, OnItemClickListener onItemClickListener) {
        this.itemList = itemList != null ? itemList : new ArrayList<>();
        this.onItemClickListener = onItemClickListener;
    }

    // Define the OnDeleteClickListener interface
    public interface OnDeleteClickListener {
        void onDeleteClick(Item item);
    }

    // setter for item click listener
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.onItemClickListener = listener;
    }

    // setter for delete click listener
    public void setOnDeleteClickListener(OnDeleteClickListener listener) {
    }

    // update item list in the adapter
    @SuppressLint("NotifyDataSetChanged")
    public void setItems(List<Item> items) {
        itemList = items;
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView itemName, itemQty;
        Button editBtn; // edit button is used for deleting too

        public ViewHolder(View view) {
            super(view);
            itemName = view.findViewById(R.id.itemNameText);
            itemQty = view.findViewById(R.id.itemQtyText);
            editBtn = view.findViewById(R.id.editBtn); // button used for edit/delete
        }
    }

    // shows items using item_row.xml
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_row, parent, false);
        return new ViewHolder(v);
    }

    // brings together page components and item features
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Item item = itemList.get(position);
        holder.itemName.setText(item.getItemName());
        holder.itemQty.setText(String.valueOf(item.getQuantity()));

        // edit button click listener
        holder.editBtn.setOnClickListener(v -> {
            // use onItemClickListener to handle item click
            if (onItemClickListener != null) {
                onItemClickListener.onEditClick(item);
            }
        });

        // item click listener for editing the item details
        holder.itemView.setOnClickListener(v -> {
            // open the EditActivity with the item details
            Intent intent = new Intent(v.getContext(), EditItemActivity.class);
            intent.putExtra("item_name", item.getItemName()); // change text color in UI
            Intent itemQuantity = intent.putExtra("item_quantity", item.getQuantity());
            v.getContext().startActivity(intent);
        });
    }

    // check to see if working?
    // can show number of items on page
    @Override
    public int getItemCount() {
        return itemList.size();
    }
}
