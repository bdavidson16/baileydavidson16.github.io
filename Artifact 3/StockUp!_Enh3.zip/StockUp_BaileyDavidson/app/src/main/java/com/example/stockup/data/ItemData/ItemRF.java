package com.example.stockup.data.ItemData;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Query; // or @Path, @Body, etc.

import java.util.List;

// sources: https://square.github.io/retrofit/declarations/
// https://github.com/square/retrofit
// https://www.geeksforgeeks.org/kotlin/how-to-get-data-from-api-using-retrofit-library-in-android/
// https://www.geeksforgeeks.org/android/how-to-post-data-to-api-using-retrofit-in-android/
public interface ItemRF {
    @GET("/items")
    Call<List<Item>> getAllItems();

    @GET("/search")
    Call<List<Item>> searchItems(@Query("q") String query);

    @POST("/insert")
    Call<Void> insertItem(@Body Item item);

    @PUT("/update")
    Call<Void> updateItem(@Body Item item);

    @DELETE("/delete")
    Call<Void> deleteItem(@Query("barcode") String barcode);
}
