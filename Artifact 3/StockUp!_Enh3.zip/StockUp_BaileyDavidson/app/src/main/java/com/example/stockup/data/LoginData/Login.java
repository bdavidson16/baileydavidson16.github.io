package com.example.stockup.data.LoginData;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

// model class - transfers from one layer to another
// name of the class "login" defines the table name, its fields' names define column names,
// and each object of it is a row in the database
@Entity(tableName = "login")
public class Login {
    @NonNull
    @PrimaryKey
    private String userName;
    private String passWord;

    public Login(){
        userName = "";
    }
    @Ignore
    public Login(@NonNull String userName, String passWord) {
        this.userName = userName;
        this.passWord = passWord;
    }

    @NonNull
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = String.valueOf(userName);
    }

    public String getPassWord() {
        return passWord;
    }

    public void setPassWord(String passWord) {
        this.passWord = passWord;
    }
}
