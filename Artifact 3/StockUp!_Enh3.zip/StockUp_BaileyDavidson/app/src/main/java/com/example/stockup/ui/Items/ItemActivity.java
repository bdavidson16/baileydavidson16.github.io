package com.example.stockup.ui.Items;

//page features
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.annotation.OptIn;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.util.Log;
import androidx.media3.common.util.UnstableApi;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.SearchView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;

// calls data files for Item info
import com.example.stockup.R;
import com.example.stockup.data.ItemData.*;
import com.example.stockup.ui.SMS.SMS;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;

// retrofit
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

// this class manages the list view of items in inventory,
// and allows the user to select the floating plus button
// or arrow to add or edit/delete items, respectively.
// Doing so by using Item, ItemRF, and ItemDatabase and applying them
// to the UI item page
// sources: https://www.geeksforgeeks.org/android-recyclerview/
// https://developer.android.com/reference/androidx/appcompat/app/AppCompatActivity
// https://developer.android.com/guide/components/intents-filters
public class ItemActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ItemRF itemRF;
    private ItemAdapter adapter; // SINGLE adapter for whole activity
    private static final int ADD_ITEM_REQUEST_CODE = 1;
    private ActivityResultLauncher<Intent> addItemLauncher;

    @OptIn(markerClass = UnstableApi.class)
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_list);

        recyclerView = findViewById(R.id.list);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        itemRF = ItemDatabase.getService();

        // initialize class-level adapter
        adapter = new ItemAdapter(new ArrayList<>());
        adapter.setOnItemClickListener(item -> {
            Intent intent = new Intent(ItemActivity.this, EditItemActivity.class);
            intent.putExtra("itemName", item.getItemName());
            addItemLauncher.launch(intent);
        });
        recyclerView.setAdapter(adapter);

        addItemLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        loadItems();
                    }
                });

        // Floating buttons
        FloatingActionButton fab = findViewById(R.id.idFABAdd);
        fab.setOnClickListener(view -> {
            Intent intent = new Intent(ItemActivity.this, EditItemActivity.class);
            addItemLauncher.launch(intent);
        });

        FloatingActionButton fabSMS = findViewById(R.id.idFABSMS);
        fabSMS.setOnClickListener(view -> {
            Intent intent = new Intent(ItemActivity.this, SMS.class);
            addItemLauncher.launch(intent);
        });

        // Search bar
        SearchView searchView = findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                searchDatabase(query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (newText.isEmpty()) {
                    loadItems();
                }
                return true;
            }
        });

        loadItems();
        ImmersiveModeHelper.enableImmersiveMode(this);
    }

    private void searchDatabase(String query) {
        itemRF.searchItems(query).enqueue(new Callback<List<Item>>() {
            @Override
            public void onResponse(Call<List<Item>> call, Response<List<Item>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    adapter.updateList(response.body());
                }
            }

            @OptIn(markerClass = UnstableApi.class)
            @Override
            public void onFailure(Call<List<Item>> call, Throwable t) {
                Log.e("ItemActivity", "Search failed", t);
            }
        });
    }

    private void loadItems() {
        itemRF.getAllItems().enqueue(new Callback<List<Item>>() {
            @OptIn(markerClass = UnstableApi.class)
            @Override
            public void onResponse(Call<List<Item>> call, Response<List<Item>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    adapter.updateList(response.body()); // update, don't replace
                } else {
                    Log.e("ItemActivity", "Failed to load items: " + response.code());
                }
            }

            @OptIn(markerClass = UnstableApi.class)
            @Override
            public void onFailure(Call<List<Item>> call, Throwable t) {
                Log.e("ItemActivity", "Error loading items", t);
            }
        });
    }
}