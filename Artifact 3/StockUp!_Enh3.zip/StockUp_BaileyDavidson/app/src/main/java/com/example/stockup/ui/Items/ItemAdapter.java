package com.example.stockup.ui.Items;

//page features
import android.annotation.SuppressLint;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

//calls item data
import com.example.stockup.R;
import com.example.stockup.data.ItemData.Item;

// used to show item data in list
import java.util.ArrayList;
import java.util.List;

// this class is used to create and manipulate a list of items from the database to
// eventually show on the UI list_items.xml
// sources: https://developer.android.com/develop/ui/views/layout/recyclerview
// https://github.com/android/views-widgets-samples/blob/main/RecyclerView/Application/src/main/java/com/example/android/recyclerview/CustomAdapter.java
public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder> {
    private List<Item> itemList = new ArrayList<>();
    private OnItemClickListener onItemClickListener;

    public ItemAdapter(List<Item> itemList) {
        this.itemList = (itemList != null) ? itemList : new ArrayList<>();
    }

    public interface OnItemClickListener {
        void onEditClick(Item item);
    }

    public ItemAdapter(List<Item> itemList, OnItemClickListener onItemClickListener) {
        this.itemList = (itemList != null) ? itemList : new ArrayList<>();
        this.onItemClickListener = onItemClickListener;
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.onItemClickListener = listener;
    }

    @SuppressLint("NotifyDataSetChanged")
    public void setItems(List<Item> items) {
        this.itemList = (items != null) ? items : new ArrayList<>();
        notifyDataSetChanged();
    }

    @SuppressLint("NotifyDataSetChanged")
    public void updateList(List<Item> newList) {
        this.itemList.clear();
        if (newList != null) {
            this.itemList.addAll(newList);
        }
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView itemName, itemQty;
        Button editBtn;

        public ViewHolder(View view) {
            super(view);
            itemName = view.findViewById(R.id.itemNameText);
            itemQty = view.findViewById(R.id.itemQtyText);
            editBtn = view.findViewById(R.id.editBtn);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_row, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Item item = itemList.get(position);
        holder.itemName.setText(item.getItemName());
        holder.itemQty.setText(String.valueOf(item.getQuantity()));

        holder.editBtn.setOnClickListener(v -> {
            if (onItemClickListener != null) {
                onItemClickListener.onEditClick(item);
            }
        });

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(v.getContext(), EditItemActivity.class);
            intent.putExtra("item_barcode", item.getBarcode());
            v.getContext().startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }
}
