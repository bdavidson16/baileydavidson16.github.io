package com.example.stockup.data.ItemData;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

// @Database is an observable data holder class - used to prevent memory leaks in this application
// basically extends database for data protection
// sources:
// https://www.geeksforgeeks.org/kotlin/how-to-get-data-from-api-using-retrofit-library-in-android/
public class ItemDatabase {
    private static Retrofit retrofit;

    public static ItemRF getService() {
        if (retrofit == null) {
            retrofit = new Retrofit.Builder()
                    .baseUrl("https://stockupapp.azurewebsites.net/") // must be your Python backend endpoint
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit.create(ItemRF.class);
    }
}