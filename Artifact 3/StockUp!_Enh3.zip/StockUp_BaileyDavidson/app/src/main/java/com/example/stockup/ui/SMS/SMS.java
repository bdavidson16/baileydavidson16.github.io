package com.example.stockup.ui.SMS;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.example.stockup.R;

//this class takes the phone number user input and enables or disables SMS notifications
// source: https://developer.android.com/reference/androidx/appcompat/app/AppCompatActivity
// https://developer.android.com/guide/components/intents-filters
// https://www.geeksforgeeks.org/what-is-toast-and-how-to-use-it-in-android-with-examples/
// https://developer.android.com/reference/android/os/Bundle

public class SMS extends AppCompatActivity {

    // input and buttons
    private EditText phoneNumberEditText;
    private Button enableBtn, disableBtn;

    // permissions and preferences
    private static final int SMS_PERMISSION_CODE = 101;
    private SharedPreferences prefs;

    // strings for pop up notifications
    private static final String PREF_NAME = "sms_prefs";
    private static final String KEY_SMS_ENABLED = "sms_enabled";
    private static final String KEY_PHONE = "phone_number";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sms); // Replace with your actual XML filename

        phoneNumberEditText = findViewById(R.id.idEdtItemName2);
        enableBtn = findViewById(R.id.btnRequestPermission);
        disableBtn = findViewById(R.id.btnDisablePermission);

        prefs = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE); //int. preference

        // on enable btn click, if phone number is null notifies user to enter phone number
        // else it enables SMS using phone number
        enableBtn.setOnClickListener(v -> {
            String phone = phoneNumberEditText.getText().toString().trim();
            if (TextUtils.isEmpty(phone)) {
                Toast.makeText(this, "Please enter a phone number", Toast.LENGTH_SHORT).show();
                return;
            }

            // Request SMS permission if not granted
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
            } else {
                enableSms(phone);
            }
        });

        // disables SMS once clicked
        disableBtn.setOnClickListener(v -> disableSms());

        // do I need 3 windows functions?
        // hide systems bar to make app fully immersive
        // source: https://developer.android.com/develop/ui/views/layout/immersive
        WindowInsetsControllerCompat windowInsetsController =
                WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());

        // Automatically hide system bars (status + nav), and let users swipe to reveal them temporarily
        windowInsetsController.setSystemBarsBehavior(
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        );

        // Hide system bars immediately
        windowInsetsController.hide(WindowInsetsCompat.Type.systemBars());
    }

    private void enableSms(String phoneNumber) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean(KEY_SMS_ENABLED, true);
        editor.putString(KEY_PHONE, phoneNumber);
        editor.apply();

        Toast.makeText(this, "SMS notifications enabled for " + phoneNumber, Toast.LENGTH_SHORT).show();
    }

    private void disableSms() {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean(KEY_SMS_ENABLED, false);
        editor.remove(KEY_PHONE);
        editor.apply();

        Toast.makeText(this, "SMS notifications disabled", Toast.LENGTH_SHORT).show();
    }
}