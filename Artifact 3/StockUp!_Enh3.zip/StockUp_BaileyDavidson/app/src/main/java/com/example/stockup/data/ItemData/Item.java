package com.example.stockup.data.ItemData;

import androidx.annotation.NonNull;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.Call;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Query;

// model class - transfers from one layer to another
// name of the class "Item" defines the table name, its fields' names define column names,
// and each object of it is a row in the database
// sources: https://www.geeksforgeeks.org/kotlin/how-to-get-data-from-api-using-retrofit-library-in-android/
//https://www.geeksforgeeks.org/android/how-to-post-data-to-api-using-retrofit-in-android/
public class Item {
    private String barcode;
    private String itemName;
    private int quantity; // smaller data type? int?

    public Item() {
        itemName = "";
    }

    public Item(String barcode, String name, int quantity) {
        this.barcode = barcode;
        this.itemName = name;
        this.quantity = quantity;
    }

    public String getBarcode() { return barcode; }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }


    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
