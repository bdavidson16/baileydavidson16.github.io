package com.example.stockup.ui.Items; // Pull UI info

import android.media.Image;
import android.os.Bundle;

// Retrofit info
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView; // For searchbar in UI

// Camera operations
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ExperimentalGetImage;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import android.view.View;
import androidx.core.content.ContextCompat;

import android.util.Log;
import android.widget.ImageButton;

import com.example.stockup.R;

// Item info
import com.example.stockup.data.ItemData.*;

// Barcode ML Kit info
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import com.google.common.util.concurrent.ListenableFuture;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutionException;

// Milestone 3 - 7/27/25*
// Enhancement 2 - Algorithms and Data Structure*
// Created a function to implement binary search rather than defaulted linear search (start at line 126)
// And implemented in onCreate() Line 82-87
// source: https://www.geeksforgeeks.org/java/binary-search-in-java/
public class SearchItemActivity extends AppCompatActivity {
    private ItemRF itemRF;
    private final List<Item> itemList = new ArrayList<>();
    private PreviewView previewView;
    private ImageButton scanButton;
    private ProcessCameraProvider cameraProvider;

    @ExperimentalGetImage
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_list); // Point to UI
        SearchView searchView = findViewById(R.id.searchView); // Find searchbar
        previewView = findViewById(R.id.previewView); // Find preview for camera*
        scanButton = findViewById(R.id.scanButton); // Find scan button

        // Connect to Database, enhancement 3
        // Created class for instance and now created new instance
        itemRF = ItemDatabase.getService();

        loadAllItems(); // load items into local cache

        previewView.setVisibility(View.GONE); // hides the preview until we click the barcode button
        scanButton.setOnClickListener(v -> {
            previewView.setVisibility(View.VISIBLE);
            scanButton.setEnabled(false);      // disable while scanning
            startCamera(); // start camera
        });

        // set listeners
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                searchItemByBarcode(query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });
    }

    // Load all items from server, store locally and sort by barcode, enh. 1
    private void loadAllItems() {
        Call<List<Item>> call = itemRF.getAllItems();
        call.enqueue(new Callback<List<Item>>() {
            @Override
            public void onResponse(@NonNull Call<List<Item>> call, @NonNull Response<List<Item>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    itemList.clear();
                    itemList.addAll(response.body()); // add items
                    Collections.sort(itemList, Comparator.comparing(Item::getBarcode)); // sort items
                    Log.d("Item", "Loaded " + itemList.size() + " items locally.");
                } else {
                    Log.e("Item", "Failed to load items: " + response.code());
                }
            }

            @Override
            public void onFailure(@NonNull Call<List<Item>> call, @NonNull Throwable t) {
                Log.e("Item", "Error loading items: " + t.getMessage());
            }
        });
    }
    // ---------- ENHANCEMENT 2 MAIN CODE --------------------
    //
    private Item binarySearchByBarcode(String targetBarcode) {
        int left = 0, right = itemList.size() - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            String midBarcode = itemList.get(mid).getBarcode();
            int cmp = midBarcode.compareTo(targetBarcode);
            if (cmp == 0) {
                return itemList.get(mid);
            } else if (cmp < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    // Eventually replace with database server retrieval (commented out below)
    // if inventory scales too much for app.
    // right now in app. searching is best and can be changed here
    // however if inventory gets too much, it will be best to let the database sort and retrieve data
    // since the app will become slower than calling the database
    private void searchItemByBarcode(String barcode) {
        Item found = binarySearchByBarcode(barcode);
        if (found != null) {
            Log.d("Item", "Found locally: " + found.getItemName());
        } else {
            Log.d("Item", "Item not found locally");

            // Uncomment below to fallback to server search if needed
            /*
            itemRF.searchItem(barcode).enqueue(new Callback<Item>() {
                @Override
                public void onResponse(@NonNull Call<Item> call, @NonNull Response<Item> response) {
                    if (response.isSuccessful()) {
                        Item item = response.body();
                        if (item != null) {
                            Log.d("Item", "Found remotely: " + item.getItemName());
                        } else {
                            Log.d("Item", "Item not found on server");
                        }
                    } else {
                        Log.d("Item", "Server error: " + response.code());
                    }
                }

                @Override
                public void onFailure(@NonNull Call<Item> call, @NonNull Throwable t) {
                    Log.e("Item", "Server call failed: " + t.getMessage());
                }
            });
            */
        }
    }

    // ---------- ENHANCEMENT 1 CODE --------------------
    // Starts camera using listener, throws error if camera isn't available
    @ExperimentalGetImage
    private void startCamera() {
        final ListenableFuture<ProcessCameraProvider> cameraProviderFuture = ProcessCameraProvider.getInstance(this);

        cameraProviderFuture.addListener(() -> {
            try {
                cameraProvider = cameraProviderFuture.get(); // ✅ safe inside try block
                bindCameraPreview(cameraProvider);
            } catch (ExecutionException | InterruptedException e) {
                Log.e("CameraX", "Failed to get camera provider", e);
            }
        }, ContextCompat.getMainExecutor(this));
    }

    // This function chooses a camera to use, creates an instance of ML kit and ImageAnalysis.
    // Then these features come together to take a photo, process the barcode, and searches
    // with the barcode if successful
    // All of this is using Android Studio's ML Kit for Barcode scanning
    // This is placed after the search function because it actively uses the search function
    // once the barcode is successfully processed
    @ExperimentalGetImage
    private void bindCameraPreview(ProcessCameraProvider cameraProvider) {
        Preview preview = new Preview.Builder().build(); // new preview

        CameraSelector cameraSelector = new CameraSelector.Builder()
                .requireLensFacing(CameraSelector.LENS_FACING_BACK) // looks at back camera
                .build();

        ImageAnalysis imageAnalysis =
                new ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build();

        BarcodeScanner scanner = BarcodeScanning.getClient(); // creates an instance of ML kit

        imageAnalysis.setAnalyzer(ContextCompat.getMainExecutor(this), imageProxy -> {
            @androidx.camera.core.ExperimentalGetImage
            Image mediaImage = imageProxy.getImage(); // takes image
            if (mediaImage != null) {
                InputImage image = InputImage.fromMediaImage(mediaImage, imageProxy.getImageInfo().getRotationDegrees());

                // if scanner processes image successfully it searches by barcode
                scanner.process(image)
                        .addOnSuccessListener(barcodes -> {
                            for (Barcode barcode : barcodes) {
                                String rawValue = barcode.getRawValue();
                                if (rawValue != null) { // searches with barcode scanned
                                    Log.d("BarcodeScanner", "Scanned barcode: " + rawValue);
                                    searchItemByBarcode(rawValue); // searches barcode
                                    imageAnalysis.clearAnalyzer();       // stops scanning
                                    cameraProvider.unbindAll();          // stops camera
                                    previewView.setVisibility(View.GONE); // hides camera preview
                                    scanButton.setEnabled(true); // resets scanner button
                                    break; // only process first barcode
                                }
                            }
                        })
                        .addOnFailureListener(e -> Log.e("BarcodeScanner", "Barcode scanning failed", e))
                        .addOnCompleteListener(task -> imageProxy.close());
            } else {
                imageProxy.close(); // if there is not image it closes the imageProxy
            }
        });

        preview.setSurfaceProvider(previewView.getSurfaceProvider());

        cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageAnalysis);
    }
}