package com.example.stockup.ui.Items;

import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import android.app.Activity;

// Hides systems bar to make app fully immersive
// source: https://developer.android.com/develop/ui/views/layout/immersive
// Added - 7/20/25
public class ImmersiveModeHelper {
    public static void enableImmersiveMode(Activity activity) {
        WindowInsetsControllerCompat windowInsetsController =
                WindowCompat.getInsetsController(activity.getWindow(), activity.getWindow().getDecorView());

        windowInsetsController.setSystemBarsBehavior(
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        );

        windowInsetsController.hide(WindowInsetsCompat.Type.systemBars());
    }
}
