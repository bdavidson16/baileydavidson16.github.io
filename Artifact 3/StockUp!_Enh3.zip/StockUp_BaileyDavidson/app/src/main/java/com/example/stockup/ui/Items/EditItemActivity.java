package com.example.stockup.ui.Items;

// page features
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

// Room used for data storage and manipulation
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

// calls data files for Item info
import com.example.stockup.R;
import com.example.stockup.data.ItemData.*;
import android.content.Intent;


// retrofit
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

// this class manages the page to edit/delete items
// by using Item and ItemRF and applying them
// to the UI item list page
// sources:   https://www.geeksforgeeks.org/toasts-android-studio/
// https://developer.android.com/reference/android/os/Bundle
// https://developer.android.com/guide/components/intents-filters
// https://www.geeksforgeeks.org/what-is-toast-and-how-to-use-it-in-android-with-examples/

public class EditItemActivity extends AppCompatActivity {
    private EditText editTextName, editTextQuantity;
    private ItemRF itemRF;
    private Item existingItem = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item); // connection to item edit page

        // fields and buttons on page
        editTextName = findViewById(R.id.idEdtItemName);
        editTextQuantity = findViewById(R.id.idEditItemQuantity);
        Button buttonSave = findViewById(R.id.idBtnSave);
        Button buttonDelete = findViewById(R.id.idBtnDelete);

        // enh. 1 --> updated immersive in separate class
        // and called to eliminate notification bar when scrolling
        ImmersiveModeHelper.enableImmersiveMode(this);

        // Enh. 3 --> updated database instance
        itemRF = ItemDatabase.getService();

        // Check for passed item barcode (primary key)
        String itemName = getIntent().getStringExtra("itemName");
        if (itemName != null) {
            itemRF.searchItems(itemName).enqueue(new Callback<List<Item>>() {
                @Override
                public void onResponse(@NonNull Call<List<Item>> call, @NonNull Response<List<Item>> response) {
                    if (response.isSuccessful() && response.body() != null && !response.body().isEmpty()) {
                        existingItem = response.body().get(0); // pick first match
                        editTextName.setText(existingItem.getItemName());
                        editTextName.setEnabled(false);
                        editTextQuantity.setText(String.valueOf(existingItem.getQuantity()));
                    } else {
                        Toast.makeText(EditItemActivity.this, "No matching item found", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(@NonNull Call<List<Item>> call, @NonNull Throwable t) {
                    Toast.makeText(EditItemActivity.this, "Error loading item", Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            buttonDelete.setEnabled(false); // disable delete for new item
        }

        // SAVE button logic
        buttonSave.setOnClickListener(v -> {
            String name = editTextName.getText().toString().trim();
            String quantityStr = editTextQuantity.getText().toString().trim();

            // Validation
            if (TextUtils.isEmpty(name) || TextUtils.isEmpty(quantityStr)) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            int quantity = Integer.parseInt(quantityStr);

            if (existingItem != null) {
                // Update existing item
                existingItem.setQuantity(quantity);
                itemRF.updateItem(existingItem).enqueue(new Callback<Void>() {
                    @Override
                    public void onResponse(Call<Void> call, Response<Void> response) {
                        Toast.makeText(EditItemActivity.this, "Item updated", Toast.LENGTH_SHORT).show();
                        setResult(RESULT_OK);
                        finish();
                    }

                    @Override
                    public void onFailure(Call<Void> call, Throwable t) {
                        Toast.makeText(EditItemActivity.this, "Update failed", Toast.LENGTH_SHORT).show();
                    }
                });
            } else {
                // Create new item
                String barcodeValue = "BC" + System.currentTimeMillis(); // Example: generate barcode
                Item newItem = new Item(barcodeValue, name, quantity);

                itemRF.insertItem(newItem).enqueue(new Callback<Void>() {
                    @Override
                    public void onResponse(Call<Void> call, Response<Void> response) {
                        Toast.makeText(EditItemActivity.this, "Item added", Toast.LENGTH_SHORT).show();
                        setResult(RESULT_OK);
                        finish();
                    }

                    @Override
                    public void onFailure(Call<Void> call, Throwable t) {
                        Toast.makeText(EditItemActivity.this, "Insert failed", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        // DELETE button logic
        buttonDelete.setOnClickListener(v -> {
            if (existingItem != null) {
                itemRF.deleteItem(existingItem.getBarcode()).enqueue(new Callback<Void>() {
                    @Override
                    public void onResponse(Call<Void> call, Response<Void> response) {
                        Toast.makeText(EditItemActivity.this, "Item deleted", Toast.LENGTH_SHORT).show();
                        setResult(RESULT_OK);
                        finish();
                    }

                    @Override
                    public void onFailure(Call<Void> call, Throwable t) {
                        Toast.makeText(EditItemActivity.this, "Delete failed", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }
}