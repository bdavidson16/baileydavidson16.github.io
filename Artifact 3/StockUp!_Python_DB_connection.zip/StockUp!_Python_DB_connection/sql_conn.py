# Connect to SQL database
# Resources:
# https://learn.microsoft.com/en-us/azure/azure-sql/database/azure-sql-python-quickstart?view=azuresql&tabs=windows%2Csql-inter
# 

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import pyodbc
import os
from dotenv import load_dotenv

load_dotenv()

app = FastAPI()

server = os.getenv("DB_SERVER")
port = os.getenv("DB_PORT", "1433")
user = os.getenv("DB_USER")
password = os.getenv("DB_PASSWORD")
database = os.getenv("DB_NAME")

# Create a connection per request
def get_connection():
    try:
        return pyodbc.connect(
            f"DRIVER={{ODBC Driver 18 for SQL Server}};"
            f"SERVER={server},{port};"
            f"DATABASE={database};"
            f"UID={user};"
            f"PWD={password};"
            "Encrypt=yes;TrustServerCertificate=no;"
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Database connection failed: {e}")

# Models
class AddItem(BaseModel):
    barcode: str
    name: str

class UpdateItem(BaseModel):
    barcode: str
    name: str

# Trigger redeploy
@app.get("/")
def read_root():
    return {"status": "API is running"}


# Add an item
@app.post("/add-item")
def add_item(item: AddItem):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO inventory (barcode, name) VALUES (?, ?)",
            (item.barcode, item.name)
        )
        conn.commit()

        # Fetch sample row
        cursor.execute("SELECT TOP 1 * FROM inventory")
        row = cursor.fetchone()
        columns = [desc[0] for desc in cursor.description] if row else []
        return {
            "message": "Item added successfully!",
            "sample": dict(zip(columns, row)) if row else None
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Insert failed: {e}")
    finally:
        cursor.close()
        conn.close()

# Get all items
@app.get("/items")
def get_items():
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM inventory")
        rows = cursor.fetchall()
        columns = [desc[0] for desc in cursor.description]
        return [dict(zip(columns, row)) for row in rows]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Query failed: {e}")
    finally:
        cursor.close()
        conn.close()

@app.get("/search")
def search_items(q: str = Query(..., min_length=1)):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM inventory WHERE name LIKE ?", ('%' + q + '%',))
        rows = cursor.fetchall()
        columns = [desc[0] for desc in cursor.description]
        return [dict(zip(columns, row)) for row in rows]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Search failed: {e}")
    finally:
        cursor.close()
        conn.close()


# Update an item
@app.put("/update-item")
def update_item(item: UpdateItem):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "UPDATE inventory SET name = ? WHERE barcode = ?",
            (item.name, item.barcode)
        )
        conn.commit()

        # Fetch updated row
        cursor.execute("SELECT * FROM inventory WHERE barcode = ?", (item.barcode,))
        row = cursor.fetchone()
        if row:
            columns = [desc[0] for desc in cursor.description]
            return {
                "message": "Update successful!",
                "item": dict(zip(columns, row))
            }
        else:
            return {"message": "Update succeeded, but item not found after update."}
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Update failed: {e}")
    finally:
        cursor.close()
        conn.close()